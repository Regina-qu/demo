﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Demo
{
    /// <summary>
    /// Логика взаимодействия для Студент.xaml
    /// </summary>
    public partial class Студент : Window
    {
        public Студент()
        {
            InitializeComponent();
        }

        private void профиль_Click(object sender, RoutedEventArgs e)
        {
            Профиль профиль = new Профиль();
            профиль.Show();
            Hide();
        }

        private void мои_баллы_Click(object sender, RoutedEventArgs e)
        {
            Аттестации аттестации = new Аттестации();
            аттестации.Show();
            Hide();
        }

        private void список_группы_Click(object sender, RoutedEventArgs e)
        {
            //Группы группы = new Группы();
            //группы.Show();
            //Hide();
        }

        private void выйти_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }
    }
}
